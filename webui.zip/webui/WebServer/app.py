# -*- coding: utf-8 -*-
#!/usr/bin/env python
from matplotlib.backends.backend_agg import FigureCanvasAgg as FigureCanvas
from matplotlib.figure import Figure
import io
from flask import Flask
from flask import render_template, request, send_file, make_response, session
import sqlite3
import sys
import time
import navio.pwm
import navio.util
import navio.ublox
reload(sys)
sys.setdefaultencoding('utf8')
from threading import Lock
from flask_socketio import SocketIO, emit, disconnect
# Set this variable to "threading", "eventlet" or "gevent" to test the
# different async modes, or leave it set to None for the application to choose
# the best option based on installed packages.
async_mode = None
app = Flask(__name__)
app.config['SECRET_KEY'] = 'secret!'
socketio = SocketIO(app, async_mode=async_mode)
thread = None
thread_lock = Lock()

#navio.util.check_apm()

pwmL = 0
pwmR = 2
pwmRev = 1
onMot = 1.150 #ms
offMot = 1.850 #ms
with navio.pwm.PWM(pwmL) as pwml,navio.pwm.PWM(pwmR) as pwmr,navio.pwm.PWM(pwmRev) as pwmrev:
    pwml.set_period(50)
    pwml.enable()
    pwmr.set_period(50)
    pwmr.enable()
    pwmrev.set_period(50)
    pwmrev.enable()
	pwml.set_duty_cycle(offMot)
	pwmr.set_duty_cycle(offMot)
	pwmrev.set_duty_cycle(offMot)
    ubl = navio.ublox.UBlox("spi:0.0", baudrate=5000000, timeout=2)

    ubl.configure_poll_port()
    ubl.configure_poll(navio.ublox.CLASS_CFG, navio.ublox.MSG_CFG_USB)
    #ubl.configure_poll(navio.ublox.CLASS_MON, navio.ublox.MSG_MON_HW)

    ubl.configure_port(port=navio.ublox.PORT_SERIAL1, inMask=1, outMask=0)
    ubl.configure_port(port=navio.ublox.PORT_USB, inMask=1, outMask=1)
    ubl.configure_port(port=navio.ublox.PORT_SERIAL2, inMask=1, outMask=0)
    ubl.configure_poll_port()
    ubl.configure_poll_port(navio.ublox.PORT_SERIAL1)
    ubl.configure_poll_port(navio.ublox.PORT_SERIAL2)
    ubl.configure_poll_port(navio.ublox.PORT_USB)
    ubl.configure_solution_rate(rate_ms=1000)

    ubl.set_preferred_dynamic_model(None)
    ubl.set_preferred_usePPP(None)

    ubl.configure_message_rate(navio.ublox.CLASS_NAV, navio.ublox.MSG_NAV_POSLLH, 1)
    ubl.configure_message_rate(navio.ublox.CLASS_NAV, navio.ublox.MSG_NAV_PVT, 1)
    ubl.configure_message_rate(navio.ublox.CLASS_NAV, navio.ublox.MSG_NAV_STATUS, 1)
    ubl.configure_message_rate(navio.ublox.CLASS_NAV, navio.ublox.MSG_NAV_SOL, 1)
    ubl.configure_message_rate(navio.ublox.CLASS_NAV, navio.ublox.MSG_NAV_VELNED, 1)
    ubl.configure_message_rate(navio.ublox.CLASS_NAV, navio.ublox.MSG_NAV_SVINFO, 1)
    ubl.configure_message_rate(navio.ublox.CLASS_NAV, navio.ublox.MSG_NAV_VELECEF, 1)
    ubl.configure_message_rate(navio.ublox.CLASS_NAV, navio.ublox.MSG_NAV_POSECEF, 1)
    ubl.configure_message_rate(navio.ublox.CLASS_RXM, navio.ublox.MSG_RXM_RAW, 1)
    ubl.configure_message_rate(navio.ublox.CLASS_RXM, navio.ublox.MSG_RXM_SFRB, 1)
    ubl.configure_message_rate(navio.ublox.CLASS_RXM, navio.ublox.MSG_RXM_SVSI, 1)
    ubl.configure_message_rate(navio.ublox.CLASS_RXM, navio.ublox.MSG_RXM_ALM, 1)
    ubl.configure_message_rate(navio.ublox.CLASS_RXM, navio.ublox.MSG_RXM_EPH, 1)
    ubl.configure_message_rate(navio.ublox.CLASS_NAV, navio.ublox.MSG_NAV_TIMEGPS, 5)
    ubl.configure_message_rate(navio.ublox.CLASS_NAV, navio.ublox.MSG_NAV_CLOCK, 5)
    #ubl.configure_message_rate(navio.ublox.CLASS_NAV, navio.ublox.MSG_NAV_DGPS, 5)

def background_thread():
    """Example of how to send server generated events to clients."""
	while True:
        msg = ubl.receive_message()
        if msg is None:
            if opts.reopen:
                ubl.close()
                ubl = navio.ublox.UBlox("spi:0.0", baudrate=5000000, timeout=2)
                continue
            print(empty)
            break
        #print(msg.name())
        if msg.name() == "NAV_POSLLH":
            outstr = str(msg).split(",")[1:]
            #outstr = "".join(outstr)
            lat = float(outstr[0].split("=")[1])
            lon = float(outstr[1].split("=")[1])
            #print(outstr)
        if msg.name() == "NAV_STATUS":
            outstr = str(msg).split(",")[1:2]
            outstr = "".join(outstr)
            #print(outstr)
        #print(str(msg))
        if lat==0 | lon==0 :
        	lat=19.1334
        	lon=72.9133
        socketio.emit('my_response',{'lat': lat,'lon':lon},namespace='/test')
		socketio.sleep(10)

	
conn=sqlite3.connect('../sensorsData.db', check_same_thread=False)
curs=conn.cursor()

@socketio.on('my_event', namespace='/test')
def test_message(message):
    print('Client myevent')
    
@socketio.on('connect', namespace='/test')
def test_connect():
    print('Client connected')
    global thread
    with thread_lock:
        if thread is None:
            thread = socketio.start_background_task(target=background_thread)
            
   
@socketio.on('disconnect', namespace='/test')
def test_disconnect():
    print('Client disconnected', request.sid)

def getHistData (numSamples):
        curs.execute("SELECT * FROM Sensor_data ORDER BY timestamp DESC LIMIT "+str(numSamples))
        data = curs.fetchall()
        dates = []
        temps = []
        phs = []
        turbs = []
        rains = []
        for row in reversed(data):
                dates.append(row[0])
                temps.append(row[1])
                phs.append(row[2])
                turbs.append(row[3])
                rains.append(row[4])
 	return dates, temps, phs, turbs, rains

def getData():
	for row in curs.execute("SELECT * FROM Sensor_data ORDER BY timestamp DESC LIMIT 1"):
		time = str(row[0])
		temp = row[1]
		ph = row[2]
		turb=row[3]
		rain=row[4]
	return time, temp, ph, turb, rain

def maxRowsTable():
	for row in curs.execute("select COUNT(temp) from  Sensor_data"):
		maxNumberRows=row[0]
	return maxNumberRows

# define and initialize global variables
global numSamples
numSamples = maxRowsTable()
if (numSamples > 101):
    numSamples = 100

@app.route("/")
def index():
    return render_template('home.html',async_mode=socketio.async_mode)

@app.route("/award.html")
def award():
    return render_template('award.html')

@app.route("/remote.html")
def remote():
    return render_template('remote.html', async_mode=socketio.async_mode )

@app.route("/home.html")
def home():
    return render_template('home.html')

@app.route("/video.html")
def video():
    return render_template('video.html')

@app.route("/sensor.html")
def sensor():
    time, temp, ph, turb, rain = getData()
    templateData = {
        'time': time,
        'temp': temp,
        'ph': ph,
        'turb': turb,
        'rain': rain
        }
    return render_template('sensorPlot.html',**templateData)

@app.route("/sensorPlot.html")
def sensorPlot():
    time, temp, ph, turb, rain = getData()
    templateData = {
        'time': time,
        'temp': temp,
        'ph': ph,
        'turb': turb,
        'rain': rain
        }
    return render_template('sensorPlot.html',**templateData)

@app.route("/historicPlot.html")
def historicPlot():
    templateData = {
	'numSamples'	: numSamples
        }
    return render_template('historicPlot.html',**templateData)

@app.route("/map.html")
def map():
    return render_template('map.html', async_mode=socketio.async_mode)

@app.route('/historicPlot.html', methods=['POST'])
def change():
    global numSamples
    # Getting the value from the webpage
    numSamples = int(request.form['numSamples'])
    numMaxSamples = maxRowsTable()
    if (numSamples > numMaxSamples):
        numSamples = (numMaxSamples-1)
    templateData = {
	'numSamples'	: numSamples
	}
    return render_template('historicPlot.html',**templateData)

@app.route('/left_side')
def left_side():
    navio.pwm.PWM(pwmL).set_duty_cycle(offMot)
	navio.pwm.PWM(pwmR).set_duty_cycle(onMot)
	navio.pwm.PWM(pwmRev).set_duty_cycle(onMot)
    data1="LEFT"
    print(data1)
    return 'true'

@app.route('/right_side')
def right_side():
	navio.pwm.PWM(pwmR).set_duty_cycle(offMot)
	navio.pwm.PWM(pwmL).set_duty_cycle(onMot)
	navio.pwm.PWM(pwmRev).set_duty_cycle(onMot)
    data1="RIGHT"
    print(data1)
    return 'true'

@app.route('/up_side')
def up_side():
	navio.pwm.PWM(pwmRev).set_duty_cycle(offMot)
	navio.pwm.PWM(pwmR).set_duty_cycle(onMot)
	navio.pwm.PWM(pwmL).set_duty_cycle(onMot)
    data1="FORWARD"
    print(data1)
    return 'true'

@app.route('/down_side')
def down_side():
	navio.pwm.PWM(pwmL).set_duty_cycle(offMot)
	navio.pwm.PWM(pwmR).set_duty_cycle(offMot)
	navio.pwm.PWM(pwmRev).set_duty_cycle(onMot)
    data1="BACK"
    print(data1)
    return 'true'

@app.route('/stop')
def stop():
   data1="STOP"
   return  'true'

@app.route('/plot/temp')
def plot_temp():
	times, temps, phs, turbs, rains = getHistData(numSamples)
	ys = temps
	fig = Figure()
	axis = fig.add_subplot(1, 1, 1)
	axis.set_title("Temperature Sensor")
	axis.set_xlabel("Samples")
	axis.set_ylabel("Temperature [°C]")
	axis.grid(True)
	xs = range(numSamples)
	axis.plot(xs, ys)
	canvas = FigureCanvas(fig)
	output = io.BytesIO()
	canvas.print_png(output)
	response = make_response(output.getvalue())
	response.mimetype = 'image/png'
	return response

@app.route('/plot/ph')
def plot_ph():
	times, temps, phs, turbs, rains = getHistData(numSamples)
	ys = phs
	fig = Figure()
	axis = fig.add_subplot(1, 1, 1)
	axis.set_title("pH Sensor")
	axis.set_xlabel("Samples")
	axis.set_ylabel("pH Value")
	axis.grid(True)
	xs = range(numSamples)
	axis.plot(xs, ys)
	canvas = FigureCanvas(fig)
	output = io.BytesIO()
	canvas.print_png(output)
	response = make_response(output.getvalue())
	response.mimetype = 'image/png'
	return response

@app.route('/plot/turb')
def plot_turb():
	times, temps, phs, turbs, rains = getHistData(numSamples)
	ys = turbs
	fig = Figure()
	axis = fig.add_subplot(1, 1, 1)
	axis.set_title("Turbidity Sensor")
	axis.set_xlabel("Samples")
	axis.set_ylabel("Voltage")
	axis.grid(True)
	xs = range(numSamples)
	axis.plot(xs, ys)
	canvas = FigureCanvas(fig)
	output = io.BytesIO()
	canvas.print_png(output)
	response = make_response(output.getvalue())
	response.mimetype = 'image/png'
	return response

@app.route('/plot/rain')
def plot_rain():
	times, temps, phs, turbs, rains = getHistData(numSamples)
	ys = rains
	fig = Figure()
	axis = fig.add_subplot(1, 1, 1)
	axis.set_title("Conductivity")
	axis.set_xlabel("Samples")
	axis.set_ylabel("Voltage")
	axis.grid(True)
	xs = range(numSamples)
	axis.plot(xs, ys)
	canvas = FigureCanvas(fig)
	output = io.BytesIO()
	canvas.print_png(output)
	response = make_response(output.getvalue())
	response.mimetype = 'image/png'
	return response

if __name__ == "__main__":
    #app.debug = True
    print("Start")
    socketio.run(app, debug=True,host='0.0.0.0',port=5010)
    

